"""
init_db.py — Run this once to set up the database.
Usage: python init_db.py
"""
import sqlite3
import json
from datetime import datetime, timedelta
import numpy as np

DB_FILE = "crop_data.db"

def init():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    # Create tables
    c.executescript('''
        CREATE TABLE IF NOT EXISTS crops (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            hindi_name TEXT,
            category TEXT,
            unit TEXT DEFAULT 'Quintal',
            avg_base_price REAL DEFAULT 2000.0
        );

        CREATE TABLE IF NOT EXISTS price_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            crop_name TEXT,
            state TEXT,
            market TEXT,
            price REAL,
            date TEXT,
            fetched_at TEXT
        );

        CREATE TABLE IF NOT EXISTS historical_prices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            crop_id INTEGER,
            state TEXT,
            price REAL,
            date TEXT,
            FOREIGN KEY (crop_id) REFERENCES crops(id)
        );
    ''')

    # Sample crops data
    crops = [
        ("Wheat", "गेहूँ", "Cereals", "Quintal", 2200),
        ("Rice", "चावल", "Cereals", "Quintal", 3000),
        ("Maize", "मक्का", "Cereals", "Quintal", 1800),
        ("Mustard", "सरसों", "Oilseeds", "Quintal", 5200),
        ("Potato", "आलू", "Vegetables", "Quintal", 1200),
        ("Onion", "प्याज", "Vegetables", "Quintal", 2500),
        ("Tomato", "टमाटर", "Vegetables", "Quintal", 2000),
        ("Tur Dal", "तुअर दाल", "Pulses", "Quintal", 6000),
        ("Cotton", "कपास", "Cash Crops", "Quintal", 6000),
        ("Mango", "आम", "Fruits", "Quintal", 5000),
    ]

    c.executemany(
        "INSERT OR IGNORE INTO crops (name, hindi_name, category, unit, avg_base_price) VALUES (?,?,?,?,?)",
        crops
    )

    conn.commit()
    conn.close()
    print(f"✅ Database '{DB_FILE}' initialized with {len(crops)} sample crops.")
    print("   Run app.py to populate full crop list automatically.")

if __name__ == "__main__":
    init()
